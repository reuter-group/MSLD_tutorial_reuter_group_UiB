#! /bin/bash
gcc -O3 -lm GibbsSample.c -o GibbsSample
