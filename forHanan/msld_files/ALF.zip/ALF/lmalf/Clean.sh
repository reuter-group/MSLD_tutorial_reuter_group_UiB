rm -r CMakeCache.txt CMakeFiles cmake_install.cmake Makefile whamweight lmalf
